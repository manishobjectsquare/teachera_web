// "use client"

// import { useRef, useEffect } from "react"
// import MessageInput from "./MessageInput"
// import ChatMessage from "./ChatMessage"


// const ChatMessageArea = ({ channel, messages, onSendMessage, currentUser, isMobileView }) => {
//   const messagesEndRef = useRef(null)
//   const messagesContainerRef = useRef(null)

//   // Auto scroll to bottom when new messages arrive
//   useEffect(() => {
//     messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
//   }, [messages])

//   const formatTime = (date) => {
//     return new Intl.DateTimeFormat("en-US", {
//       hour: "2-digit",
//       minute: "2-digit",
//       hour12: true,
//     }).format(date)
//   }

//   const formatDate = (date) => {
//     const today = new Date()
//     const messageDate = new Date(date)

//     if (messageDate.toDateString() === today.toDateString()) {
//       return "Today"
//     }

//     const yesterday = new Date(today)
//     yesterday.setDate(yesterday.getDate() - 1)

//     if (messageDate.toDateString() === yesterday.toDateString()) {
//       return "Yesterday"
//     }

//     return messageDate.toLocaleDateString()
//   }

//   // Group messages by date
//   const groupedMessages = messages?.reduce((groups, message) => {
//     const date = formatDate(message.timestamp)
//     if (!groups[date]) {
//       groups[date] = []
//     }
//     groups[date].push(message)
//     return groups
//   }, {})

//   if (!channel) {
//     return (
//       <div className="message-area">
//         <div className="welcome-screen">
//           <div className="welcome-content">
//             <div className="welcome-icon">
//               <i className="fas fa-comments"></i>
//             </div>
//             <h3>Welcome to Teachera Community!</h3>
//             <p>Connect with fellow students, ask questions, and share your learning journey.</p>
//             <div className="welcome-features">
//               <div className="feature-item">
//                 <i className="fas fa-users"></i>
//                 <span>Join study groups and discussions</span>
//               </div>
//               <div className="feature-item">
//                 <i className="fas fa-question-circle"></i>
//                 <span>Get help from instructors and peers</span>
//               </div>
//               <div className="feature-item">
//                 <i className="fas fa-share-alt"></i>
//                 <span>Share your projects and achievements</span>
//               </div>
//             </div>
//             <p className="welcome-cta">Select a channel from the menu to start chatting!</p>
//           </div>
//         </div>

//         <style jsx>{`
//           .welcome-screen {
//             flex: 1;
//             display: flex;
//             align-items: center;
//             justify-content: center;
//             background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
//             padding: 40px 20px;
//           }

//           .welcome-content {
//             text-align: center;
//             max-width: 400px;
//           }

//           .welcome-icon {
//             font-size: 4rem;
//             color: #667eea;
//             margin-bottom: 1.5rem;
//           }

//           .welcome-content h3 {
//             color: #495057;
//             margin-bottom: 1rem;
//             font-weight: 600;
//           }

//           .welcome-content > p {
//             color: #6c757d;
//             margin-bottom: 2rem;
//             line-height: 1.6;
//           }

//           .welcome-features {
//             display: flex;
//             flex-direction: column;
//             gap: 1rem;
//             margin-bottom: 2rem;
//           }

//           .feature-item {
//             display: flex;
//             align-items: center;
//             gap: 12px;
//             color: #495057;
//             font-size: 0.9rem;
//           }

//           .feature-item i {
//             color: #667eea;
//             width: 20px;
//           }

//           .welcome-cta {
//             color: #667eea !important;
//             font-weight: 600;
//             font-size: 0.9rem;
//           }

//           @media (max-width: 768px) {
//             .welcome-screen {
//               padding: 20px;
//             }

//             .welcome-icon {
//               font-size: 3rem;
//             }
//           }
//         `}</style>
//       </div>
//     )
//   }

//   return (
//     <div className="message-area">
//       <div className="message-header">
//         <div className="channel-info">
//           <h5>
//             <i className="fas fa-hashtag me-2"></i>
//             {channel?.name}
//           </h5>
//           <p>{channel?.description}</p>
//         </div>
//         <div className="channel-stats">
//           <span className="member-count">
//             <i className="fas fa-users me-1"></i>
//             {channel?.memberCount}
//           </span>
//         </div>
//       </div>

//       <div className="messages-container" ref={messagesContainerRef}>
//         {Object.entries(groupedMessages).map(([date, dateMessages]) => (
//           <div key={date}>
//             <div className="date-separator">
//               <span>{date}</span>
//             </div>
//             {dateMessages.map((message, index) => (
//               <ChatMessage
//                 key={message.id}
//                 message={message}
//                 isOwn={message.user.name === currentUser.name}
//                 showAvatar={index === 0 || dateMessages[index - 1].user.name !== message.user.name}
//                 formatTime={formatTime}
//               />
//             ))}
//           </div>
//         ))}
//         <div ref={messagesEndRef} />
//       </div>

//       <MessageInput onSendMessage={onSendMessage} />

//       <style jsx>{`
//         .message-area {
//           flex: 1;
//           display: flex;
//           flex-direction: column;
//           background: white;
//         }

//         .message-header {
//           padding: 16px 20px;
//           border-bottom: 1px solid #e9ecef;
//           background: white;
//           display: flex;
//           justify-content: space-between;
//           align-items: center;
//         }

//         .channel-info h5 {
//           margin: 0 0 4px 0;
//           color: #495057;
//           font-weight: 600;
//           display: flex;
//           align-items: center;
//         }

//         .channel-info p {
//           margin: 0;
//           color: #6c757d;
//           font-size: 14px;
//         }

//         .channel-stats {
//           display: flex;
//           align-items: center;
//           gap: 16px;
//         }

//         .member-count {
//           color: #6c757d;
//           font-size: 14px;
//           display: flex;
//           align-items: center;
//         }

//         .messages-container {
//           flex: 1;
//           overflow-y: auto;
//           padding: 16px 0;
//           background: #fafbfc;
//         }

//         .date-separator {
//           display: flex;
//           align-items: center;
//           margin: 20px 20px 16px;
//           position: relative;
//         }

//         .date-separator::before {
//           content: '';
//           flex: 1;
//           height: 1px;
//           background: #e9ecef;
//           margin-right: 16px;
//         }

//         .date-separator::after {
//           content: '';
//           flex: 1;
//           height: 1px;
//           background: #e9ecef;
//           margin-left: 16px;
//         }

//         .date-separator span {
//           color: #6c757d;
//           font-size: 12px;
//           font-weight: 600;
//           text-transform: uppercase;
//           background: #fafbfc;
//           padding: 0 8px;
//         }

//         .messages-container::-webkit-scrollbar {
//           width: 6px;
//         }

//         .messages-container::-webkit-scrollbar-track {
//           background: transparent;
//         }

//         .messages-container::-webkit-scrollbar-thumb {
//           background: #dee2e6;
//           border-radius: 3px;
//         }

//         @media (max-width: 768px) {
//           .message-header {
//             padding: 12px 16px;
//           }

//           .channel-info h5 {
//             font-size: 16px;
//           }

//           .channel-info p {
//             font-size: 13px;
//           }
//         }
//       `}</style>
//     </div>
//   )
// }

// export default ChatMessageArea



"use client"

import { useRef, useEffect } from "react"
import MessageInput from "./MessageInput"
import ChatMessage from "./ChatMessage"


const ChatMessageArea = ({ channel, messages, onSendMessage, currentUser, isMobileView }) => {
  const messagesEndRef = useRef(null)
  const messagesContainerRef = useRef(null)

  // Auto scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const formatTime = (date) => {
    return new Intl.DateTimeFormat("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    }).format(date)
  }

  const formatDate = (date) => {
    const today = new Date()
    const messageDate = new Date(date)

    if (messageDate.toDateString() === today.toDateString()) {
      return "Today"
    }

    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)

    if (messageDate.toDateString() === yesterday.toDateString()) {
      return "Yesterday"
    }

    return messageDate.toLocaleDateString()
  }

  // Group messages by date
  const groupedMessages =
    (messages || []).reduce((groups, message) => {
      const date = formatDate(message.timestamp)
      if (!groups[date]) {
        groups[date] = []
      }
      groups[date].push(message)
      return groups
    }, {}) || {}

  if (!channel) {
    return (
      <div className="message-area">
        <div className="welcome-screen">
          <div className="welcome-content">
            <div className="welcome-icon">
              <i className="fas fa-comments"></i>
            </div>
            <h3>Welcome to Teachera Community!</h3>
            <p>Connect with fellow students, ask questions, and share your learning journey.</p>
            <div className="welcome-features">
              <div className="feature-item">
                <i className="fas fa-users"></i>
                <span>Join study groups and discussions</span>
              </div>
              <div className="feature-item">
                <i className="fas fa-question-circle"></i>
                <span>Get help from instructors and peers</span>
              </div>
              <div className="feature-item">
                <i className="fas fa-share-alt"></i>
                <span>Share your projects and achievements</span>
              </div>
            </div>
            <p className="welcome-cta">Select a channel from the menu to start chatting!</p>
          </div>
        </div>

        <style jsx>{`
        .welcome-screen {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
          padding: 40px 20px;
        }
        
        .welcome-content {
          text-align: center;
          max-width: 400px;
        }
        
        .welcome-icon {
          font-size: 4rem;
          color: #667eea;
          margin-bottom: 1.5rem;
        }
        
        .welcome-content h3 {
          color: #495057;
          margin-bottom: 1rem;
          font-weight: 600;
        }
        
        .welcome-content > p {
          color: #6c757d;
          margin-bottom: 2rem;
          line-height: 1.6;
        }
        
        .welcome-features {
          display: flex;
          flex-direction: column;
          gap: 1rem;
          margin-bottom: 2rem;
        }
        
        .feature-item {
          display: flex;
          align-items: center;
          gap: 12px;
          color: #495057;
          font-size: 0.9rem;
        }
        
        .feature-item i {
          color: #667eea;
          width: 20px;
        }
        
        .welcome-cta {
          color: #667eea !important;
          font-weight: 600;
          font-size: 0.9rem;
        }
        
        @media (max-width: 768px) {
          .welcome-screen {
            padding: 20px;
          }
          
          .welcome-icon {
            font-size: 3rem;
          }
        }
      `}</style>
      </div>
    )
  }

  return (
    <div className="message-area">
      <div className="message-header">
        <div className="channel-info">
          <h5>
            <i className="fas fa-hashtag me-2"></i>
            {channel?.name}
          </h5>
          <p>{channel?.description}</p>
        </div>
        <div className="channel-stats">
          <span className="member-count">
            <i className="fas fa-users me-1"></i>
            {channel?.memberCount}
          </span>
        </div>
      </div>

      <div className="messages-container" ref={messagesContainerRef}>
        {Object.entries(groupedMessages).map(([date, dateMessages]) => (
          <div key={date}>
            <div className="date-separator">
              <span>{date}</span>
            </div>
            {dateMessages.map((message, index) => (
              <ChatMessage
                key={message.id}
                message={message}
                isOwn={message.user.name === currentUser.name}
                showAvatar={index === 0 || dateMessages[index - 1].user.name !== message.user.name}
                formatTime={formatTime}
              />
            ))}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <MessageInput onSendMessage={onSendMessage} />

      <style jsx>{`
      .message-area {
        flex: 1;
        display: flex;
        flex-direction: column;
        background: white;
      }

      .message-header {
        padding: 16px 20px;
        border-bottom: 1px solid #e9ecef;
        background: white;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .channel-info h5 {
        margin: 0 0 4px 0;
        color: #495057;
        font-weight: 600;
        display: flex;
        align-items: center;
      }

      .channel-info p {
        margin: 0;
        color: #6c757d;
        font-size: 14px;
      }

      .channel-stats {
        display: flex;
        align-items: center;
        gap: 16px;
      }

      .member-count {
        color: #6c757d;
        font-size: 14px;
        display: flex;
        align-items: center;
      }

      .messages-container {
        flex: 1;
        overflow-y: auto;
        padding: 16px 0;
        background: #fafbfc;
      }

      .date-separator {
        display: flex;
        align-items: center;
        margin: 20px 20px 16px;
        position: relative;
      }

      .date-separator::before {
        content: '';
        flex: 1;
        height: 1px;
        background: #e9ecef;
        margin-right: 16px;
      }

      .date-separator::after {
        content: '';
        flex: 1;
        height: 1px;
        background: #e9ecef;
        margin-left: 16px;
      }

      .date-separator span {
        color: #6c757d;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        background: #fafbfc;
        padding: 0 8px;
      }

      .messages-container::-webkit-scrollbar {
        width: 6px;
      }

      .messages-container::-webkit-scrollbar-track {
        background: transparent;
      }

      .messages-container::-webkit-scrollbar-thumb {
        background: #dee2e6;
        border-radius: 3px;
      }

      @media (max-width: 768px) {
        .message-header {
          padding: 12px 16px;
        }

        .channel-info h5 {
          font-size: 16px;
        }

        .channel-info p {
          font-size: 13px;
        }
      }
    `}</style>
    </div>
  )
}

export default ChatMessageArea
