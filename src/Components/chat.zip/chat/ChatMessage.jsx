"use client"

import userImg from "/user.jpg"

const ChatMessage = ({ message, isOwn, showAvatar, formatTime }) => {
  const getRoleColor = (role) => {
    switch (role?.toLowerCase()) {
      case "instructor":
        return "#10b981"
      case "moderator":
        return "#f59e0b"
      case "admin":
        return "#ef4444"
      default:
        return "#6c757d"
    }
  }

  const getRoleBadge = (role) => {
    if (!role || role.toLowerCase() === "student") return null

    return (
      <span className="role-badge" style={{ backgroundColor: getRoleColor(role) }}>
        {role}
      </span>
    )
  }

  return (
    <div className={`message ${isOwn ? "own-message" : ""} ${showAvatar ? "with-avatar" : "no-avatar"}`}>
      <div className="message-content">
        {!isOwn && showAvatar && (
          <div className="message-avatar">
            <img
              src={userImg || "/placeholder.svg"}
              alt={message.user.name}
              onError={(e) => {
                e.target.src = "/placeholder.svg"
              }}
            />
          </div>
        )}

        <div className="message-body">
          {!isOwn && showAvatar && (
            <div className="message-header">
              <span className="username" style={{ color: getRoleColor(message.user.role) }}>
                {message.user.name}
              </span>
              {getRoleBadge(message.user.role)}
              <span className="timestamp">{formatTime(message.timestamp)}</span>
            </div>
          )}

          <div className="message-text">
            {message.type === "image" ? (
              <div className="message-image">
                <img src={message.content || "/placeholder.svg"} alt="Shared image" />
              </div>
            ) : (
              <div className={`message-bubble ${isOwn ? "own-bubble" : "other-bubble"}`}>
                <p>{message.content}</p>
                {isOwn && <span className="own-timestamp">{formatTime(message.timestamp)}</span>}
              </div>
            )}
          </div>
        </div>
      </div>

      <style jsx>{`
        .message {
          padding: 2px 16px;
          margin-bottom: 1px;
        }

        .message.with-avatar {
          padding: 6px 16px;
          margin-bottom: 4px;
        }

        .message-content {
          display: flex;
          gap: 8px;
          align-items: flex-end;
        }

        .own-message .message-content {
          justify-content: flex-end;
        }

        .message-avatar {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          overflow: hidden;
          flex-shrink: 0;
        }

        .message-avatar img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .message-body {
          max-width: 65%;
          min-width: 0;
        }

        .own-message .message-body {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
        }

        .message-header {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-bottom: 2px;
          font-size: 13px;
        }

        .username {
          font-weight: 600;
          font-size: 13px;
        }

        .role-badge {
          color: white;
          font-size: 9px;
          font-weight: 600;
          padding: 1px 4px;
          border-radius: 8px;
          text-transform: uppercase;
          letter-spacing: 0.3px;
        }

        .timestamp {
          color: #6c757d;
          font-size: 11px;
          margin-left: auto;
        }

        .message-bubble {
          padding: 6px 12px;
          border-radius: 16px;
          max-width: 100%;
          word-wrap: break-word;
          display: inline-block;
        }

        .other-bubble {
          background: #f1f3f4;
          border-bottom-left-radius: 4px;
        }

        .own-bubble {
          background: #667eea;
          color: white;
          border-bottom-right-radius: 4px;
        }

        .message-bubble p {
          margin: 0;
          font-size: 14px;
          line-height: 1.4;
        }

        .own-timestamp {
          font-size: 10px;
          color: rgba(255, 255, 255, 0.7);
          margin-top: 2px;
          display: block;
          text-align: right;
        }

        /* Consecutive messages spacing */
        .message.no-avatar:not(.own-message) .message-content {
          margin-left: 40px;
        }

        .message.no-avatar.own-message .message-content {
          margin-right: 0;
        }

        .message-image img {
          max-width: 250px;
          max-height: 180px;
          border-radius: 12px;
          cursor: pointer;
        }

        @media (max-width: 768) {
          .message {
            padding: 2px 12px;
          }

          .message.with-avatar {
            padding: 4px 12px;
          }

          .message-avatar {
            width: 28px;
            height: 28px;
          }

          .message-body {
            max-width: 75%;
          }

          .message.no-avatar:not(.own-message) .message-content {
            margin-left: 36px;
          }

          .message-bubble {
            padding: 5px 10px;
          }

          .message-bubble p {
            font-size: 13px;
          }
        }

        /* RTL styles */
        [dir="rtl"] .message-content {
          flex-direction: row-reverse;
        }

        [dir="rtl"] .own-message .message-content {
          justify-content: flex-start;
        }

        [dir="rtl"] .message-header {
          flex-direction: row-reverse;
        }

        [dir="rtl"] .timestamp {
          margin-left: 0;
          margin-right: auto;
        }

        [dir="rtl"] .own-bubble {
          border-bottom-right-radius: 16px;
          border-bottom-left-radius: 4px;
        }

        [dir="rtl"] .other-bubble {
          border-bottom-left-radius: 16px;
          border-bottom-right-radius: 4px;
        }

        [dir="rtl"] .message.no-avatar:not(.own-message) .message-content {
          margin-left: 0;
          margin-right: 40px;
        }

        [dir="rtl"] .own-timestamp {
          text-align: left;
        }
      `}</style>
    </div>
  )
}

export default ChatMessage
