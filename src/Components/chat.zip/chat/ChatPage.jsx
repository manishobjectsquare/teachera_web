"use client"

import { useState, useEffect } from "react"
import { useUser } from "../../Context/UserContext"
import axios from "axios"
import { baseUrl } from "../../config/baseUrl"
import { socket } from "../../config/socket"
import ChatChannelList from "./ChatChannelList"
import ChatMessageArea from "./ChatMessageArea"
import ChatMemberList from "./ChatMemberList"


// Mock current user for demonstration until your context is fully wired
const MOCK_CURRENT_USER = {
    name: "Test User",
    avatar: "/placeholder.svg",
    role: "Student",
}

export default function ChatPage() {
    const { user } = useUser()
    const currentUser = user || MOCK_CURRENT_USER

    const [selectedChannel, setSelectedChannel] = useState(null)
    const [messages, setMessages] = useState({})
    const [onlineUsers, setOnlineUsers] = useState([])
    const [isMobileView, setIsMobileView] = useState(false)
    const [showMemberList, setShowMemberList] = useState(false)
    const [showChannels, setShowChannels] = useState(false)
    const [channels, setChannels] = useState([])

    useEffect(() => {
        const fetchChatGroups = async () => {
            if (!currentUser?.userId) return
            try {
                const response = await axios.get(`${baseUrl}/api/v1/web/chat/group-chat/${currentUser.userId}`)
                if (response.data.status) {
                    setChannels(response.data.chatGroups)
                }
            } catch (err) {
                console.error("Error fetching chat groups:", err)
            }
        }
        fetchChatGroups()
    }, [currentUser?.userId])

    useEffect(() => {
        setOnlineUsers([
            { id: 1, name: "Sarah Johnson", avatar: "/placeholder.svg", status: "online", role: "Student" },
            { id: 2, name: "Mike Chen", avatar: "/placeholder.svg", status: "online", role: "Instructor" },
            { id: 3, name: "Emily Davis", avatar: "/placeholder.svg", status: "away", role: "Student" },
            { id: 4, name: "Alex Rodriguez", avatar: "/placeholder.svg", status: "online", role: "Student" },
            { id: 5, name: "Lisa Wang", avatar: "/placeholder.svg", status: "busy", role: "Moderator" },
        ])
    }, [])

    useEffect(() => {
        const handleResize = () => {
            const mobile = window.innerWidth < 768
            setIsMobileView(mobile)
            setShowChannels(!mobile)
            if (!mobile) {
                setShowMemberList(true) // Show member list by default on desktop
            }
        }
        handleResize()
        window.addEventListener("resize", handleResize)
        return () => window.removeEventListener("resize", handleResize)
    }, [])

    const handleSendMessage = (content, type = "text") => {
        socket.emit("send-message", {
            chatGroupId: selectedChannel,
            senderId: currentUser?.userId,
            content: content,
            type: type,
        })
    }

    const handleChannelSelect = (channelId) => {
        setSelectedChannel(channelId)
        if (isMobileView) {
            setShowChannels(false)
        }
    }

    return (
        <div className="chat-page-container">
            <div className="chat-header">
                <div className="chat-title">
                    <i className="fas fa-comments me-2"></i>
                    <span>Teachera Community</span>
                </div>
                <div className="chat-controls">
                    <button
                        className="channel-toggle-btn"
                        onClick={() => setShowChannels(!showChannels)}
                        title="Toggle Categories"
                    >
                        Categories
                    </button>
                    {!isMobileView && (
                        <button
                            className="member-toggle-btn"
                            onClick={() => setShowMemberList(!showMemberList)}
                            title="Toggle Member List"
                        >
                            <i className="fas fa-users"></i>
                        </button>
                    )}
                </div>
            </div>

            <div className="chat-body">
                {showChannels && (
                    <ChatChannelList
                        channels={channels}
                        selectedChannel={selectedChannel}
                        onChannelSelect={handleChannelSelect}
                        isMobileView={isMobileView}
                    />
                )}

                <ChatMessageArea
                    channel={channels.find((c) => c._id === selectedChannel)}
                    onSendMessage={handleSendMessage}
                    currentUser={currentUser}
                    isMobileView={isMobileView}
                />

                {!isMobileView && showMemberList && (
                    <ChatMemberList
                        users={onlineUsers}
                        channelMemberCount={channels.find((c) => c._id === selectedChannel)?.memberCount}
                    />
                )}
            </div>

            <style jsx>{`
        .chat-page-container {
          display: flex;
          flex-direction: column;
          height: 100vh;
          width: 100%;
          background: white;
          overflow: hidden;
        }

        .chat-header {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          padding: 16px 20px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
          flex-shrink: 0;
        }

        .chat-title {
          display: flex;
          align-items: center;
          font-weight: 600;
          font-size: 18px;
        }

        .chat-controls {
          display: flex;
          gap: 8px;
        }

        .channel-toggle-btn,
        .member-toggle-btn {
          background: rgba(255, 255, 255, 0.1);
          border: none;
          color: white;
          height: 36px;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.2s ease;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 0 12px;
        }
        
        .member-toggle-btn {
            width: 36px;
        }

        .channel-toggle-btn:hover,
        .member-toggle-btn:hover {
          background: rgba(255, 255, 255, 0.2);
        }

        .chat-body {
          display: flex;
          flex: 1;
          overflow: hidden;
          position: relative; /* For absolute positioning of mobile channel list */
        }
      `}</style>
        </div>
    )
}
